..
    This file is part of the dionaea honeypot

    SPDX-FileCopyrightText: 2011-2012 Markus Koetter
    SPDX-FileCopyrightText: 2015-2017 PhiBo (DinoTools)

    SPDX-License-Identifier: GPL-2.0-or-later

Processors
==========

Processors control the actions done on the bi-directional streams we gain when getting attacked, the default is running the emu processor on them to detect shellcode.

.. toctree::

    emu
    filter
    streamdumper
