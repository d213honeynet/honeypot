..
    This file is part of the dionaea honeypot

    SPDX-FileCopyrightText: 2016 PhiBo (DinoTools)

    SPDX-License-Identifier: GPL-2.0-or-later

hpfeeds
=======

Example config
--------------

.. literalinclude:: ../../../conf/ihandlers/hpfeeds.yaml
   :language: yaml
   :caption: ihandlers/hpfeeds.yaml
