..
    This file is part of the dionaea honeypot

    SPDX-FileCopyrightText: 2011-2012 Markus Koetter
    SPDX-FileCopyrightText: 2015-2017 PhiBo (DinoTools)

    SPDX-License-Identifier: GPL-2.0-or-later

EPMAP
=====

Example config
--------------

.. literalinclude:: ../../../conf/services/epmap.yaml
    :language: yaml
    :caption: services/epmap.yaml
