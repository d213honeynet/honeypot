..
    This file is part of the dionaea honeypot

    SPDX-FileCopyrightText: 2016 PhiBo (DinoTools)

    SPDX-License-Identifier: GPL-2.0-or-later

UPnP
====

Example config
--------------

.. literalinclude:: ../../../conf/services/upnp.yaml.in
    :language: yaml
    :caption: services/upnp.yaml
