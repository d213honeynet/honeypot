..
    This file is part of the dionaea honeypot

    SPDX-FileCopyrightText: 2011-2012 Markus Koetter
    SPDX-FileCopyrightText: 2015-2017 PhiBo (DinoTools)

    SPDX-License-Identifier: GPL-2.0-or-later

Support
=======

Cui honorem, honorem
--------------------

Google:

    Google has supported 3 students to work on dionaea during GSoc 2009, GSoc 2010 and GSoc 2011.

SURFnet:

    `SURFnet`_ has supported the project in the past(2010?-2014?).
    Working with SURFnet is a real pleasure.

Support
-------

If you are getting frustrated, because things to not work for you and you already read the :doc:`faq`, join the ml and share your experience,
or the chat.

GitHub

    Use the issue tracker to report any problem.

    Website: `Issue tracker <https://github.com/DinoTools/dionaea/issues>`_

IRC

    From time to time some of the developers join the #nepenthes channel on freenode. `irc://irc.freenode.org/nepenthes <irc://irc.freenode.org/nepenthes>`_

Mailing List:

    Only a few messages every year.
    Seems to be dead, no message since 2015.

    Website: `Mailinglist nepenthes-devel <https://lists.sourceforge.net/lists/listinfo/nepenthes-devel>`_


Links
-----

  * GSoC 2009 Project #10 http://honeynet.org/gsoc/project10
  * `The Honeynet Project <http://honeynet.org/>`_

.. _SURFnet: https://www.surf.nl/
